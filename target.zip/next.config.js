module.exports = {
    images: {
      remotePatterns: [
        {
          protocol: 'https',
          hostname: 'dependable-creativity-a1557309a6.media.strapiapp.com',
        },
        // {
        //   protocol: 'http',
        //   hostname: 'localhost'
        // }
      ],
    },
    env: {
        STRAPI_URL: 'https://dependable-creativity-a1557309a6.strapiapp.com/',
        TOKEN: 'aa3674ed0bf4142499b6251517a43799523efe8c6fd471b9c20139d189e0972108a44e3981d9484978cf833d21d1c66ba785d8ffaea05cd242d24b2aa10c0d4dedbc0cd6ff6f53d56387dabda300d5e184006c9fbde294f04cd4cac636b25ecb87974c3caa3d992d09711481bbfe2ef2ada9dfb2e6dde4b7b9a6132621851aa9'
    },
  }