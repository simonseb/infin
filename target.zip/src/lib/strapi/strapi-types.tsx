export const StrapiImageFields = {
  fields: ['name', 'alternativeText', 'width', 'height', 'url'],
}

export const StrapiVideoFields = {
  fields: ['name', 'alternativeText', 'width', 'height', 'url'],
}

export const StrapiButtonFields = {
  fields: ['label', 'href', 'target'],
}
