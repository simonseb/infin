export const colors = {
  light: '#fff',
  dark: '#121212',
  accent: '#ffcd00',
  semiDark: 'rgba(18, 18, 18, 0.16)',
  grey: '#c1c1c1',
  lightGrey: '#f3f3f3',
  darkGrey: '#6b6b6b',
  red: '#f00',
};
