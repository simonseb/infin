# The Infin landing page.

## Getting Started

- npm install
- npm run dev
- Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.


